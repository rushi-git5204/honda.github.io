# Our-Team-Section-M6
How to create the Our Team Section Using HTML and CSS
